package com.arbnor.xauai

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var tvSignal: TextView
    private lateinit var tvConfidence: TextView
    private lateinit var tvBuyScore: TextView
    private lateinit var tvSellScore: TextView
    private lateinit var tvEntry: TextView
    private lateinit var tvSl: TextView
    private lateinit var tvTp1: TextView
    private lateinit var tvTp2: TextView
    private lateinit var tvDxy: TextView
    private lateinit var tvSession: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvAction: TextView
    private lateinit var tvStatus: TextView
    private lateinit var etEndpoint: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSignal = findViewById(R.id.tvSignal)
        tvConfidence = findViewById(R.id.tvConfidence)
        tvBuyScore = findViewById(R.id.tvBuyScore)
        tvSellScore = findViewById(R.id.tvSellScore)
        tvEntry = findViewById(R.id.tvEntry)
        tvSl = findViewById(R.id.tvSl)
        tvTp1 = findViewById(R.id.tvTp1)
        tvTp2 = findViewById(R.id.tvTp2)
        tvDxy = findViewById(R.id.tvDxy)
        tvSession = findViewById(R.id.tvSession)
        tvMode = findViewById(R.id.tvMode)
        tvAction = findViewById(R.id.tvAction)
        tvStatus = findViewById(R.id.tvStatus)
        etEndpoint = findViewById(R.id.etEndpoint)

        val prefs = getSharedPreferences("xauai", MODE_PRIVATE)
        etEndpoint.setText(prefs.getString("endpoint", ""))

        findViewById<Button>(R.id.btnDemo).setOnClickListener {
            renderSignal(
                JSONObject(
                    """{
                      "direction":"BUY",
                      "confidence":0.81,
                      "buy_score":81,
                      "sell_score":18,
                      "entry":4317.20,
                      "sl":4310.40,
                      "tp1":4325.90,
                      "tp2":4330.80,
                      "dxy":"BEARISH",
                      "session":"NEW YORK",
                      "mode":"PULLBACK",
                      "action":"BUY CONFIRMED"
                    }"""
                )
            )
            tvStatus.text = "Demo signal loaded"
        }

        findViewById<Button>(R.id.btnRefresh).setOnClickListener {
            val endpoint = etEndpoint.text.toString().trim()
            if (endpoint.isBlank()) {
                tvStatus.text = "Enter your AI API endpoint first"
                return@setOnClickListener
            }
            prefs.edit().putString("endpoint", endpoint).apply()
            fetchSignal(endpoint)
        }
    }

    private fun fetchSignal(endpoint: String) {
        tvStatus.text = "Loading…"
        thread {
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Accept", "application/json")
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) throw IllegalStateException("HTTP $code: $body")
                val json = JSONObject(body)
                runOnUiThread {
                    renderSignal(json)
                    tvStatus.text = "Updated"
                }
            } catch (e: Exception) {
                runOnUiThread { tvStatus.text = "Error: ${e.message ?: "connection failed"}" }
            }
        }
    }

    private fun renderSignal(j: JSONObject) {
        val direction = j.optString("direction", "NO_TRADE").uppercase()
        val confRaw = j.optDouble("confidence", 0.0)
        val confidence = if (confRaw <= 1.0) confRaw * 100.0 else confRaw

        tvSignal.text = direction.replace("_", " ")
        tvSignal.setTextColor(
            when (direction) {
                "BUY" -> Color.parseColor("#2ECC71")
                "SELL" -> Color.parseColor("#EF5350")
                else -> Color.parseColor("#F4B942")
            }
        )
        tvConfidence.text = "Confidence %.0f%%".format(confidence.coerceIn(0.0, 100.0))
        tvBuyScore.text = number(j, "buy_score", "p_buy")
        tvSellScore.text = number(j, "sell_score", "p_sell")
        tvEntry.text = "Entry: ${price(j, "entry")}" 
        tvSl.text = "SL: ${price(j, "sl")}" 
        tvTp1.text = "TP1: ${price(j, "tp1")}" 
        tvTp2.text = "TP2: ${price(j, "tp2")}" 
        tvDxy.text = "DXY: ${j.optString("dxy", j.optString("dxy_bias", "—"))}"
        tvSession.text = "Session: ${j.optString("session", "—")}"
        tvMode.text = "Mode: ${j.optString("mode", "—")}"
        tvAction.text = "Action: ${j.optString("action", direction)}"
    }

    private fun price(j: JSONObject, key: String): String {
        if (!j.has(key) || j.isNull(key)) return "—"
        return try { "%.2f".format(j.getDouble(key)) } catch (_: Exception) { "—" }
    }

    private fun number(j: JSONObject, key: String, probKey: String): String {
        return when {
            j.has(key) && !j.isNull(key) -> try { "%.0f".format(j.getDouble(key)) } catch (_: Exception) { "0" }
            j.has(probKey) && !j.isNull(probKey) -> try { "%.0f".format(j.getDouble(probKey) * 100.0) } catch (_: Exception) { "0" }
            else -> "0"
        }
    }
}
