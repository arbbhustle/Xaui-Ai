package com.arbnor.xauai

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var tvSignal: TextView
    private lateinit var tvConfidence: TextView
    private lateinit var tvBuyScore: TextView
    private lateinit var tvSellScore: TextView
    private lateinit var tvEntry: TextView
    private lateinit var tvSl: TextView
    private lateinit var tvTp1: TextView
    private lateinit var tvTp2: TextView
    private lateinit var tvSession: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvAction: TextView
    private lateinit var tvSource: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvUpdated: TextView
    private lateinit var tvDecisionHint: TextView
    private lateinit var tvRsi: TextView
    private lateinit var tvAtr: TextView
    private lateinit var tvEfficiency: TextView
    private lateinit var tvEdge: TextView
    private lateinit var tvStructure: TextView
    private lateinit var tvPressure: TextView
    private lateinit var tvVolatility: TextView
    private lateinit var tvBreakout: TextView
    private lateinit var tvReasons: TextView
    private lateinit var tvWinRate: TextView
    private lateinit var tvTotalR: TextView
    private lateinit var tvTradesCount: TextView
    private lateinit var tvOpenTrade: TextView
    private lateinit var tvApiChip: TextView
    private lateinit var etEndpoint: EditText

    private val handler = Handler(Looper.getMainLooper())
    private val autoScanMs = 5 * 60 * 1000L
    private var isFetching = false

    private val autoScan = object : Runnable {
        override fun run() {
            val endpoint = etEndpoint.text.toString().trim()
            if (endpoint.isNotBlank()) fetchDashboard(endpoint, silent = true)
            handler.postDelayed(this, autoScanMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()

        val prefs = getSharedPreferences("xauai", MODE_PRIVATE)
        val defaultEndpoint = "https://xau-ai-trader-android.onrender.com/signal"
        etEndpoint.setText(prefs.getString("endpoint", defaultEndpoint) ?: defaultEndpoint)

        findViewById<Button>(R.id.btnRefresh).setOnClickListener {
            val endpoint = etEndpoint.text.toString().trim()
            if (endpoint.isBlank()) {
                tvStatus.text = "Add API endpoint first"
                return@setOnClickListener
            }
            prefs.edit().putString("endpoint", endpoint).apply()
            fetchDashboard(endpoint, silent = false)
        }

        fetchDashboard(etEndpoint.text.toString().trim(), silent = false)
    }

    override fun onStart() {
        super.onStart()
        handler.removeCallbacks(autoScan)
        handler.postDelayed(autoScan, autoScanMs)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(autoScan)
    }

    private fun bindViews() {
        tvSignal = findViewById(R.id.tvSignal)
        tvConfidence = findViewById(R.id.tvConfidence)
        tvBuyScore = findViewById(R.id.tvBuyScore)
        tvSellScore = findViewById(R.id.tvSellScore)
        tvEntry = findViewById(R.id.tvEntry)
        tvSl = findViewById(R.id.tvSl)
        tvTp1 = findViewById(R.id.tvTp1)
        tvTp2 = findViewById(R.id.tvTp2)
        tvSession = findViewById(R.id.tvSession)
        tvMode = findViewById(R.id.tvMode)
        tvAction = findViewById(R.id.tvAction)
        tvSource = findViewById(R.id.tvSource)
        tvStatus = findViewById(R.id.tvStatus)
        tvUpdated = findViewById(R.id.tvUpdated)
        tvDecisionHint = findViewById(R.id.tvDecisionHint)
        tvRsi = findViewById(R.id.tvRsi)
        tvAtr = findViewById(R.id.tvAtr)
        tvEfficiency = findViewById(R.id.tvEfficiency)
        tvEdge = findViewById(R.id.tvEdge)
        tvStructure = findViewById(R.id.tvStructure)
        tvPressure = findViewById(R.id.tvPressure)
        tvVolatility = findViewById(R.id.tvVolatility)
        tvBreakout = findViewById(R.id.tvBreakout)
        tvReasons = findViewById(R.id.tvReasons)
        tvWinRate = findViewById(R.id.tvWinRate)
        tvTotalR = findViewById(R.id.tvTotalR)
        tvTradesCount = findViewById(R.id.tvTradesCount)
        tvOpenTrade = findViewById(R.id.tvOpenTrade)
        tvApiChip = findViewById(R.id.tvApiChip)
        etEndpoint = findViewById(R.id.etEndpoint)
    }

    private fun fetchDashboard(endpoint: String, silent: Boolean) {
        if (endpoint.isBlank() || isFetching) return
        isFetching = true
        if (!silent) tvStatus.text = "Scanning market intelligence…"
        tvApiChip.text = "● SYNC"
        tvApiChip.setTextColor(Color.parseColor("#57D4FF"))

        thread {
            try {
                val signal = getJson(endpoint)
                val performanceUrl = endpoint.substringBeforeLast("/") + "/performance"
                val performance = try { getJson(performanceUrl) } catch (_: Exception) { null }

                runOnUiThread {
                    renderSignal(signal)
                    if (performance != null) renderPerformance(performance)
                    tvStatus.text = "Live engine synced • auto-scan every 5 min"
                    tvApiChip.text = "● LINKED"
                    tvApiChip.setTextColor(Color.parseColor("#22D38A"))
                    isFetching = false
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvStatus.text = "Connection error: ${e.message ?: "unknown"}"
                    tvApiChip.text = "● OFFLINE"
                    tvApiChip.setTextColor(Color.parseColor("#FF5E68"))
                    isFetching = false
                }
            }
        }
    }

    private fun getJson(endpoint: String): JSONObject {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "AurumCore-Android/2.0")
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            JSONObject(body)
        } finally {
            conn.disconnect()
        }
    }

    private fun renderSignal(j: JSONObject) {
        val direction = j.optString("direction", "NO_TRADE").uppercase()
        val confRaw = j.optDouble("confidence", 0.0)
        val confidence = if (confRaw <= 1.0) confRaw * 100.0 else confRaw
        val buyScore = j.optDouble("buy_score", 0.0)
        val sellScore = j.optDouble("sell_score", 0.0)

        tvSignal.text = direction.replace("_", " ")
        val signalColor = when (direction) {
            "BUY" -> "#22D38A"
            "SELL" -> "#FF5E68"
            else -> "#F5B83B"
        }
        tvSignal.setTextColor(Color.parseColor(signalColor))
        tvConfidence.text = "Confidence %.0f%%".format(confidence.coerceIn(0.0, 100.0))
        tvBuyScore.text = "%.0f".format(buyScore)
        tvSellScore.text = "%.0f".format(sellScore)

        tvEntry.text = "Entry  ${price(j, "entry")}"
        tvSl.text = "Stop  ${price(j, "sl")}"
        tvTp1.text = "TP1  ${price(j, "tp1")}"
        tvTp2.text = "TP2  ${price(j, "tp2")}"

        tvRsi.text = "RSI  ${decimal(j, "rsi_state", 1)}"
        tvAtr.text = "ATR  ${decimal(j, "atr", 2)}"
        tvEfficiency.text = "Efficiency  ${percentMetric(j, "efficiency")}"
        tvEdge.text = "Edge  ${decimal(j, "edge", 0)}"
        tvStructure.text = "Structure  ${signedMetric(j, "structure")}"
        tvPressure.text = "Pressure  ${signedMetric(j, "pressure")}"
        tvVolatility.text = "Volatility  ${j.optString("volatility", "—")}"
        tvBreakout.text = "Breakout  ${signedMetric(j, "breakout_bias")}"

        tvSession.text = "Session  ${j.optString("session", "—")}"
        tvMode.text = "Regime  ${j.optString("mode", "—")}"
        tvSource.text = "Feed  ${j.optString("market_source", "—")} • ${j.optString("timeframe", "—")}"
        tvAction.text = "Action  ${j.optString("action", direction)}"
        tvAction.setTextColor(Color.parseColor(signalColor))

        val reasons = j.optJSONArray("reasons")
        tvReasons.text = formatReasons(reasons)
        tvDecisionHint.text = decisionHint(direction, confidence, j.optString("mode", ""))
        tvUpdated.text = formatTimestamp(j.optString("timestamp_utc", ""))
    }

    private fun renderPerformance(j: JSONObject) {
        val winRate = j.optDouble("win_rate_pct", 0.0)
        val totalR = j.optDouble("total_r", 0.0)
        val closed = j.optInt("closed_trades", 0)
        val wins = j.optInt("wins", 0)
        val losses = j.optInt("losses", 0)

        tvWinRate.text = "Win rate\n%.1f%%".format(winRate)
        tvTotalR.text = "Total R\n%+.2f".format(totalR)
        tvTradesCount.text = "Trades\n$closed"

        val openTrade = j.optJSONObject("open_trade")
        tvOpenTrade.text = if (openTrade == null) {
            "Scanner state: no open demo trade • $wins W / $losses L"
        } else {
            val d = openTrade.optString("direction", "")
            val e = if (openTrade.has("entry")) "%.2f".format(openTrade.optDouble("entry")) else "—"
            "OPEN DEMO $d @ $e • TP1 ${if (openTrade.optBoolean("tp1_hit")) "HIT" else "pending"}"
        }
    }

    private fun formatReasons(a: JSONArray?): String {
        if (a == null || a.length() == 0) return "• Engine is waiting for a cleaner market edge"
        val lines = mutableListOf<String>()
        for (i in 0 until minOf(a.length(), 5)) {
            val raw = a.optString(i).trim()
            if (raw.isNotBlank()) lines.add("• ${raw.replaceFirstChar { it.uppercase() }}")
        }
        return lines.joinToString("\n")
    }

    private fun decisionHint(direction: String, confidence: Double, mode: String): String {
        return when (direction) {
            "BUY" -> "Bullish edge detected. Demo engine has enough agreement to build a long blueprint."
            "SELL" -> "Bearish edge detected. Demo engine has enough agreement to build a short blueprint."
            else -> when {
                mode.contains("RANGE", ignoreCase = true) -> "Noise regime detected. Engine is protecting capital by waiting."
                confidence >= 50 -> "Directional pressure exists, but confirmation is below the execution threshold."
                else -> "No clean edge yet. The engine is scanning structure, momentum and volatility."
            }
        }
    }

    private fun price(j: JSONObject, key: String): String {
        if (!j.has(key) || j.isNull(key)) return "—"
        return try { "%.2f".format(j.getDouble(key)) } catch (_: Exception) { "—" }
    }

    private fun decimal(j: JSONObject, key: String, digits: Int): String {
        if (!j.has(key) || j.isNull(key)) return "—"
        val format = "%.${digits}f"
        return try { String.format(format, j.getDouble(key)) } catch (_: Exception) { "—" }
    }

    private fun percentMetric(j: JSONObject, key: String): String {
        if (!j.has(key) || j.isNull(key)) return "—"
        return try { "%.0f%%".format(j.getDouble(key) * 100.0) } catch (_: Exception) { "—" }
    }

    private fun signedMetric(j: JSONObject, key: String): String {
        if (!j.has(key) || j.isNull(key)) return "—"
        return try { "%+.2f".format(j.getDouble(key)) } catch (_: Exception) { "—" }
    }

    private fun formatTimestamp(value: String): String {
        if (value.isBlank()) return "—"
        return try {
            val instant = Instant.parse(value)
            val formatter = DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault())
            formatter.format(instant)
        } catch (_: Exception) {
            "LIVE"
        }
    }
}
